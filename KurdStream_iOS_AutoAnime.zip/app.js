let episodesList = [];
let currentIndex = 0;
let autoNextTimer = null;

const player = document.getElementById('animePlayer');
const videoSource = document.getElementById('videoSource');
const kuSubtitle = document.getElementById('kuSubtitle');
const episodesGrid = document.getElementById('episodesGrid');
const currentEpBadge = document.getElementById('currentEpBadge');
const currentEpTitle = document.getElementById('currentEpTitle');
const episodeCount = document.getElementById('episodeCount');
const autoPlayBanner = document.getElementById('autoPlayBanner');
const cancelAutoBtn = document.getElementById('cancelAutoBtn');

// Load episodes automatically from episodes.json (or remote API)
async function initApp() {
    try {
        const response = await fetch('episodes.json?t=' + Date.now());
        const data = await response.json();
        episodesList = data.episodes || [];
        episodeCount.textContent = `${episodesList.length} ئەڵقە`;
        renderEpisodes();
        if (episodesList.length > 0) {
            loadEpisode(0, false);
        }
    } catch (error) {
        console.error('هەڵە لە بارکردنی ئەڵقەکان:', error);
    }
}

function renderEpisodes() {
    episodesGrid.innerHTML = '';
    episodesList.forEach((ep, index) => {
        const btn = document.createElement('button');
        btn.className = 'ep-btn' + (index === currentIndex ? ' active' : '');
        btn.innerHTML = `
            <span class="ep-num">ئەڵقەی ${ep.number}</span>
            <span class="ep-name">${ep.title}</span>
        `;
        btn.onclick = () => loadEpisode(index, true);
        episodesGrid.appendChild(btn);
    });
}

function forceKurdishSubtitles() {
    // Ensure iOS Safari automatically displays the WebVTT track without manual toggling
    if (player.textTracks && player.textTracks.length > 0) {
        for (let i = 0; i < player.textTracks.length; i++) {
            player.textTracks[i].mode = (player.textTracks[i].language === 'ku') ? 'showing' : 'disabled';
        }
    }
}

function loadEpisode(index, shouldPlay = true) {
    clearTimeout(autoNextTimer);
    autoPlayBanner.classList.add('hidden');
    currentIndex = index;
    const ep = episodesList[index];

    currentEpBadge.textContent = `وەرزی ${ep.season} • ئەڵقەی ${ep.number}`;
    currentEpTitle.textContent = ep.title;

    videoSource.src = ep.videoUrl;
    kuSubtitle.src = ep.subtitleUrl;

    player.load();
    renderEpisodes();

    player.addEventListener('loadedmetadata', () => {
        forceKurdishSubtitles();
        if (shouldPlay) {
            player.play().catch(() => {});
        }
    }, { once: true });
}

// Automatically advance to the next episode when current finishes
player.addEventListener('ended', () => {
    if (currentIndex + 1 < episodesList.length) {
        autoPlayBanner.classList.remove('hidden');
        autoNextTimer = setTimeout(() => {
            loadEpisode(currentIndex + 1, true);
        }, 3000);
    }
});

cancelAutoBtn.addEventListener('click', () => {
    clearTimeout(autoNextTimer);
    autoPlayBanner.classList.add('hidden');
});

// Keep subtitles active on iOS fullscreen transitions
player.addEventListener('webkitbeginfullscreen', forceKurdishSubtitles);
player.addEventListener('play', forceKurdishSubtitles);

initApp();
